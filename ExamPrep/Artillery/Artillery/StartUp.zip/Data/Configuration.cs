﻿namespace Artillery.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=SKYNET\SQLEXPRESS;Database=Artillery;Integrated Security=True;Encrypt=False";
    }
}
