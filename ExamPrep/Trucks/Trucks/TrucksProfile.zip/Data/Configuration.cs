﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=SKYNET\SQLEXPRESS;Database=Trucks;Trusted_Connection=True";
    }
}