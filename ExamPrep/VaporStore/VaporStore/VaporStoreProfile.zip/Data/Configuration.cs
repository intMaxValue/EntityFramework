﻿namespace VaporStore.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=SKYNET\SQLEXPRESS;Database=VaporStore;Integrated Security=True;Encrypt=False";
    }
}