﻿namespace VaporStore.Data.Models.Enums
{
    public enum PurchaseType
    {
        Retail = 0,
        Digital = 1,
    }
}
