﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=SKYNET\SQLEXPRESS;Database=Invoices;Integrated Security=True;Encrypt=False;TrustServerCertificate=True;Trusted_Connection=True";
    }
}
