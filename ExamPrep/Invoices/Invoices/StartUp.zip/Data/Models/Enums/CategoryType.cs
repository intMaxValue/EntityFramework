﻿namespace Invoices.Data.Models.Enums
{
    public enum CategoryType
    {
        ADR = 0,
        Filters = 1,
        Lights = 2,
        Others = 3,
        Tyres = 4,
    }
}
