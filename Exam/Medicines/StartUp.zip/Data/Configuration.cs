﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString =
            @"Server=SKYNET\SQLEXPRESS;Database=Medicines;TrustServerCertificate=True;Trusted_Connection=True;";
    }
}
