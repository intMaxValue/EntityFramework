﻿namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=SKYNET\SQLEXPRESS;Database=CarDealer;Trusted_Connection=True;Integrated Security=True;Encrypt=False";
    }
}
