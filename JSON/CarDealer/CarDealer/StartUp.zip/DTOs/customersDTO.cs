﻿
namespace CarDealer.DTOs;

    public class customersDTO
    {
        public string Name { get; set; }
        public string BirthDate { get; set; }
        public bool IsYoungDriver { get; set; }
    }

